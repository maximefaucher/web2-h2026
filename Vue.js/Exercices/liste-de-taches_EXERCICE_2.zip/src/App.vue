<script setup>
import HeaderComponent from './components/HeaderComponent.vue';
import FooterComponent from './components/FooterComponent.vue';
</script>

<template>
  <div class="bg-gray-100 min-h-screen flex flex-col">
    <HeaderComponent/>
    <RouterView />
    <FooterComponent/>
  </div>
</template>
