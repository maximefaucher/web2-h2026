<template>
  <div class="flex gap-2 mb-5">
    <input
      v-model="newTodo"
      @keyup.enter="submit"
      type="text"
      placeholder="Ajouter une tâche…"
      class="flex-1 border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-200"
    />
    <button
      @click="submit"
      class="bg-blue-500 hover:bg-blue-600 text-white text-sm px-4 py-2 rounded-lg"
    >
      Ajouter
    </button>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const emit = defineEmits(['add'])
const newTodo = ref('')

function submit() {
  if (!newTodo.value.trim()) return
  emit('add', newTodo.value.trim())
  newTodo.value = ''
}
</script>