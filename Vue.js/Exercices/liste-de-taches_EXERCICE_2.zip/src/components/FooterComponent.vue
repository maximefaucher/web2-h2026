<template>
    <footer class="border-t border-gray-200 mt-auto">
      <div class="max-w-4xl mx-auto px-4 h-12 flex items-center justify-center">
        <p class="text-xs text-gray-400">
          © {{ new Date().getFullYear() }} Todo App — Fait avec Vue 3 & Tailwind CSS
        </p>
      </div>
    </footer>
</template>
