<template>
  <li class="flex items-center gap-3 px-3 py-2.5 border border-gray-100 rounded-lg text-sm"
    :class="todo.done ? 'text-gray-400 line-through' : 'text-gray-800'">
    <input type="checkbox" :checked="todo.done"
      @change="$emit('toggle', todo.id)"
      class="w-4 h-4 accent-blue-500" />
    <span>{{ todo.text }}</span>
  </li>
</template>

<script setup>
defineProps({ todo: Object })
defineEmits(['toggle'])
</script>