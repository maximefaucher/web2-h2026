<template>
  <div>
    <p class="text-xs text-gray-400 mb-3">{{ remaining }} tâche(s) restante(s)</p>
    <ul class="flex flex-col gap-2">
      <TodoItem
        v-for="todo in todos"
        :key="todo.id"
        :todo="todo"
        @toggle="$emit('toggle', $event)"
      />
    </ul>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import TodoItem from './TodoItem.vue'

const props = defineProps({ todos: Array })
defineEmits(['toggle'])

const remaining = computed(() => props.todos.filter(t => !t.done).length)
</script>