<template>
  <div class="bg-gray-100 min-h-screen flex items-center justify-center">
    <div class="bg-gray-100 min-h-screen flex items-center justify-center">
      <div class="bg-white rounded-xl shadow-sm p-6 w-full max-w-md">
        <h1 class="text-xl font-medium text-gray-800 mb-4">Ma todo list</h1>
        <TodoForm @add="addTodo" />
        <TodoList :todos="todos" @toggle="toggleTodo" />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, watch } from 'vue';
import TodoForm from '@/components/TodoForm.vue';
import TodoList from '@/components/TodoList.vue';

// liste de tâches
const defaultTodos = [
  { id: 1, text: 'Apprendre Vue 3', done: false },
  { id: 2, text: 'Installer Node.js', done: true },
  { id: 3, text: 'Faire l\'exercice de la liste de tâches', done: false },
]

const stored = localStorage.getItem('todos')
const todos = ref(stored ? JSON.parse(stored) : defaultTodos)

watch(
  todos,
  (newTodos) => localStorage.setItem('todos', JSON.stringify(newTodos)),
  { deep: true }
)

function addTodo(text) {
  todos.value.push({ id: crypto.randomUUID(), text, done: false })
}

function toggleTodo(id) {
  const todo = todos.value.find(t => t.id === id)
  if (todo) todo.done = !todo.done
}
</script>
