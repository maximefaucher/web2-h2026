<template>
  <main class="max-w-4xl mx-auto px-4 py-16 flex flex-col items-center text-center gap-6">
    <div class="text-5xl">✅</div>
    <h1 class="text-3xl font-semibold text-gray-800">
      Bienvenue sur Todo App
    </h1>
    <p class="text-gray-500 max-w-sm leading-relaxed">
      Une application simple pour gérer tes tâches au quotidien.
      Ajoute, coche, et retrouve tes tâches en un clin d'œil.
    </p>
    <RouterLink
      to="/taches"
      class="bg-blue-500 hover:bg-blue-600 text-white text-sm font-medium px-6 py-2.5 rounded-lg transition-colors"
    >
      Voir mes tâches →
    </RouterLink>
  </main>
</template>