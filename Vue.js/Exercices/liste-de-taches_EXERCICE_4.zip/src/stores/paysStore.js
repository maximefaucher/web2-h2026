import { defineStore } from 'pinia'
import { ref } from 'vue'
import { getPaysParRegion } from '@/services/paysService'

export const usePaysStore = defineStore('pays', () => {
  const pays = ref([])
  const chargement = ref(false)
  const erreur = ref(null)

  async function chargerPays() {
    if (pays.value.length > 0) return  // cache : évite un 2e appel API

    chargement.value = true
    erreur.value = null
    try {
      pays.value = await getPaysParRegion()
    } catch (e) {
      erreur.value = e.message
    } finally {
      chargement.value = false
    }
  }

  return { pays, chargement, erreur, chargerPays }
})
