import { defineStore } from 'pinia'
import { ref, watch } from 'vue'

const defaultTodos = [
  { id: 1, text: 'Apprendre Vue 3', done: false },
  { id: 2, text: 'Installer Node.js', done: true },
  { id: 3, text: 'Faire l\'exercice de la liste de tâches', done: false },
]

export const useTodoStore = defineStore('todo', () => {
  const stored = localStorage.getItem('todos')
  const todos = ref(stored ? JSON.parse(stored) : defaultTodos)

  // Persistance automatique dans localStorage à chaque changement
  watch(todos, (val) => localStorage.setItem('todos', JSON.stringify(val)), { deep: true })

  function addTodo(text) {
    todos.value.push({ id: crypto.randomUUID(), text, done: false })
  }

  function toggleTodo(id) {
    const todo = todos.value.find(t => t.id === id)
    if (todo) todo.done = !todo.done
  }

  return { todos, addTodo, toggleTodo }
})