<script setup>
import { useTodoStore } from '@/stores/todoStore'
import TodoForm from '@/components/TodoForm.vue'
import TodoList from '@/components/TodoList.vue'

const store = useTodoStore()
</script>

<template>
  <div class="bg-gray-100 min-h-screen flex items-center justify-center">
    <div class="bg-gray-100 min-h-screen flex items-center justify-center">
      <div class="bg-white rounded-xl shadow-sm p-6 w-full max-w-md">
        <h1 class="text-xl font-medium text-gray-800 mb-4">Ma todo list</h1>
        <TodoForm @add="store.addTodo" />
        <TodoList :todos="store.todos" @toggle="store.toggleTodo" />
      </div>
    </div>
  </div>
</template>
