<script setup>
import { ref, computed, onMounted } from 'vue'
import { getPaysParRegion } from '@/services/paysService'

const pays       = ref([])
const chargement = ref(true)
const erreur     = ref(null)
const recherche  = ref('')

onMounted(async () => {
  try {
    pays.value = await getPaysParRegion()
  } catch (e) {
    erreur.value = e.message
  } finally {
    chargement.value = false
  }
})

const paysFiltres = computed(() =>
  pays.value.filter(p =>
    p.name.common.toLowerCase().includes(recherche.value.toLowerCase())
  )
)
</script>

<template>
  <main class="max-w-4xl mx-auto px-4 py-10">
    <h1 class="text-2xl font-semibold text-gray-800 mb-6">Pays des Amériques</h1>

    <!-- État : chargement -->
    <p v-if="chargement" class="text-gray-400">Chargement...</p>

    <!-- État : erreur -->
    <p v-else-if="erreur" class="text-red-500">{{ erreur }}</p>

    <!-- État : données reçues -->
    <div v-else>

      <!-- Barre de recherche -->
      <div class="flex items-center gap-2 mb-4">
        <input
          v-model="recherche"
          type="text"
          placeholder="Rechercher un pays..."
          class="border border-gray-300 rounded-lg px-4 py-2 text-sm w-64 focus:outline-none focus:ring-2 focus:ring-blue-300"
        />
        <button
          v-if="recherche"
          @click="recherche = ''"
          class="text-sm text-gray-400 hover:text-red-400 transition-colors"
        >
          ✕ Effacer
        </button>
      </div>

      <!-- Compteur -->
      <p class="text-sm text-gray-400 mb-4">{{ paysFiltres.length }} pays affichés</p>

      <!-- Grille -->
      <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        <RouterLink
          v-for="p in paysFiltres"
          :key="p.name.common"
          :to="`/pays/${encodeURIComponent(p.name.common)}`"
          class="bg-white rounded-xl shadow-sm p-4 flex flex-col items-center
                 gap-2 hover:shadow-md transition-shadow"
        >
          <img :src="p.flags.svg" :alt="p.name.common" class="w-16 h-10 object-cover rounded" />
          <span class="text-sm text-center text-gray-700">{{ p.name.common }}</span>
        </RouterLink>
      </div>

      <!-- Aucun résultat -->
      <p v-if="paysFiltres.length === 0" class="text-gray-400 mt-6">
        Aucun pays ne correspond à « {{ recherche }} ».
      </p>

    </div>
  </main>
</template>
