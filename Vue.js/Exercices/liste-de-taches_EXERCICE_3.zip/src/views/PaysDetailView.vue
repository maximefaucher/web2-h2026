<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { getPaysParNom } from '@/services/paysService.js'

const route      = useRoute()
const pays       = ref(null)
const chargement = ref(true)
const erreur     = ref(null)

onMounted(async () => {
  try {
    const nom = decodeURIComponent(route.params.nom)
    pays.value = await getPaysParNom(nom)
  } catch (e) {
    erreur.value = e.message
  } finally {
    chargement.value = false
  }
})

// Formate un objet currencies : { CAD: { name: 'Canadian dollar', symbol: '$' } }
function formatDevise(currencies) {
  if (!currencies) return 'N/A'
  return Object.values(currencies)
    .map(c => `${c.name} (${c.symbol})`)
    .join(', ')
}
</script>

<template>
  <main class="max-w-2xl mx-auto px-4 py-10">

    <p v-if="chargement" class="text-gray-400">Chargement...</p>
    <p v-else-if="erreur" class="text-red-500">{{ erreur }}</p>

    <div v-else-if="pays">
      <!-- En-tête : drapeau + nom -->
      <div class="flex items-center gap-4 mb-8">
        <img :src="pays.flags.svg" :alt="pays.name.common"
             class="w-24 h-16 object-cover rounded shadow" />
        <h1 class="text-3xl font-semibold text-gray-800">
          {{ pays.name.common }}
        </h1>
      </div>

      <!-- Informations -->
      <dl class="grid grid-cols-2 gap-4 text-sm">
        <div>
          <dt class="text-gray-400 font-medium">Capitale</dt>
          <dd class="text-gray-800">{{ pays.capital?.[0] ?? 'N/A' }}</dd>
        </div>
        <div>
          <dt class="text-gray-400 font-medium">Population</dt>
          <dd class="text-gray-800">{{ pays.population.toLocaleString('fr-CA') }}</dd>
        </div>
        <div>
          <dt class="text-gray-400 font-medium">Superficie</dt>
          <dd class="text-gray-800">{{ pays.area.toLocaleString('fr-CA') }} km²</dd>
        </div>
        <div>
          <dt class="text-gray-400 font-medium">Devise</dt>
          <dd class="text-gray-800">{{ formatDevise(pays.currencies) }}</dd>
        </div>
      </dl>

      <!-- Lien Google Maps -->
      <a
        :href="pays.maps.googleMaps"
        target="_blank"
        rel="noopener"
        class="mt-8 inline-block bg-blue-500 hover:bg-blue-600
               text-white text-sm font-medium px-5 py-2 rounded-lg transition-colors"
      >
        Voir sur Google Maps →
      </a>
    </div>
    
    <!-- Retour -->
    <div class="mt-4">
      <RouterLink to="/pays"
        class="text-sm text-gray-400 hover:text-blue-500 transition-colors"
      >
        ← Retour à la liste
      </RouterLink>
    </div>

  </main>
</template>