<template>
    <header class="bg-white border-b border-gray-200 sticky top-0 z-10">
      <div class="max-w-4xl mx-auto px-4 h-14 flex items-center justify-between">
        <RouterLink to="/" class="text-blue-500 font-semibold text-base tracking-tight">
          ✅ Todo App
        </RouterLink>
        <nav class="flex gap-6 text-sm">
          <RouterLink
            to="/"
            class="text-gray-500 hover:text-blue-500 transition-colors"
            active-class="text-blue-500 font-medium"
          >
            Accueil
          </RouterLink>
          <RouterLink
            to="/taches"
            class="text-gray-500 hover:text-blue-500 transition-colors"
            active-class="text-blue-500 font-medium"
          >
            Tâches
          </RouterLink>
          <RouterLink
            to="/pays"
            class="text-gray-500 hover:text-blue-500 transition-colors"
            active-class="text-blue-500 font-medium"
          >
            Pays
          </RouterLink>
        </nav>
      </div>
    </header>
</template>