import { createRouter, createWebHistory } from 'vue-router'
import AccueilView from '@/views/AccueilView.vue'
import TachesView from '@/views/TachesView.vue'
import PaysView       from '@/views/PaysView.vue'
import PaysDetailView from '@/views/PaysDetailView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    { path: '/', name: 'accueil', component: AccueilView },
    { path: '/taches', name: 'liste-de-taches', component: TachesView },
    { path: '/pays',      name: 'pays-liste',  component: PaysView },
    { path: '/pays/:nom', name: 'pays-detail', component: PaysDetailView },
  ],
})

export default router