// src/services/paysService.js
// Couche service : toute la communication avec l'API est ici.
// Les composants Vue n'appellent jamais fetch() directement.

const BASE_URL = 'https://restcountries.com/v3.1'

// Champs nécessaires pour la liste
const CHAMPS_LISTE = 'name,flags'

// Champs nécessaires pour la fiche détaillée
const CHAMPS_DETAILS = 'name,flags,capital,population,area,currencies,maps'

const REGION = 'americas'

/**
 * Récupère les pays de la région Amériques.
 * @returns {Promise<Array>} Liste triée alphabétiquement
 */
export async function getPaysParRegion() {
  const response = await fetch(
    `${BASE_URL}/region/${REGION}?fields=${CHAMPS_LISTE}`
  )
  if (!response.ok) throw new Error(`Erreur API : ${response.status}`)
  const data = await response.json()
  return data.sort((a, b) => a.name.common.localeCompare(b.name.common))
}

/**
 * Récupère un pays par son nom commun.
 * @param {string} nom - Nom du pays (ex. "Canada")
 * @returns {Promise<Object>} Données complètes du pays
 */
export async function getPaysParNom(nom) {
  const response = await fetch(
    `${BASE_URL}/name/${encodeURIComponent(nom)}?fullText=true&fields=${CHAMPS_DETAILS}`
  )
  if (!response.ok) throw new Error(`Pays introuvable : ${nom}`)
  const data = await response.json()
  return data[0]
}